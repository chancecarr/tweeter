import { MemoryRouter } from "react-router-dom";
import PostStatus from "../../../src/components/postStatus/PostStatus";
import { render, screen } from "@testing-library/react";
import { UserEvent, userEvent } from "@testing-library/user-event";
import "@testing-library/jest-dom";
import { library } from "@fortawesome/fontawesome-svg-core";
import { fab } from "@fortawesome/free-brands-svg-icons";
import { PostStatusPresenter } from "../../../src/presenter/PostStatusPresenter";
import { anything, instance, mock, verify, when } from "@typestrong/ts-mockito";
import { useUserInfo } from "../../../src/components/userInfo/UserInfoActions";
import { AuthToken, User } from "tweeter-shared";

library.add(fab);

jest.mock("../../../src/components/userInfo/UserInfoActions", () => ({
  ...jest.requireActual("../../../src/components/userInfo/UserInfoActions"),
  __esModule: true,
  useUserInfo: jest.fn(),
}));

describe("Post Status Compnent", () => {
  const mockUser = mock<User>();
  const mockAuthToken = mock<AuthToken>();
  const mockUserInstance = instance(mockUser);
  const mockAuthTokenInstance = instance(mockAuthToken);

  beforeAll(() => {
    (useUserInfo as jest.Mock).mockReturnValue({
      currentUser: mockUserInstance,
      authToken: mockAuthTokenInstance,
    });
  });

  it("starts with both buttons disabled", () => {
    const { postStatusButton, clearStatusButton } =
      renderPostStatusAndGetElement();
    expect(postStatusButton).toBeDisabled();
    expect(clearStatusButton).toBeDisabled();
  });

  it("enables both buttons if the text field has text", async () => {
    const { user, postStatusButton, clearStatusButton, postStatusTextArea } =
      renderPostStatusAndGetElement();
    await fillFieldAndCheck(
      user,
      postStatusButton,
      clearStatusButton,
      postStatusTextArea,
    );
  });

  it("disables both buttons if the text field is cleared", async () => {
    const { user, postStatusButton, clearStatusButton, postStatusTextArea } =
      renderPostStatusAndGetElement();
    await fillFieldAndCheck(
      user,
      postStatusButton,
      clearStatusButton,
      postStatusTextArea,
    );
    await user.clear(postStatusTextArea);
    expect(postStatusButton).toBeDisabled();
    expect(clearStatusButton).toBeDisabled();
  });

  it("calls the presenter's postStatus method with correct parameters when the post status button is pressed", async () => {
    const mockPresenter = mock<PostStatusPresenter>();
    const mockPresenterInstance = instance(mockPresenter);

    const { user, postStatusButton, postStatusTextArea } =
      renderPostStatusAndGetElement(mockPresenterInstance);
    await user.type(postStatusTextArea, "a");
    await user.click(postStatusButton);
    verify(mockPresenter.submitPost(anything(), "a")).once();
  });
});

function renderPostStatus(presenter?: PostStatusPresenter) {
  return render(
    <MemoryRouter>
      {!!presenter ? <PostStatus presenter={presenter} /> : <PostStatus />}
    </MemoryRouter>,
  );
}

function renderPostStatusAndGetElement(presenter?: PostStatusPresenter) {
  const user = userEvent.setup();

  renderPostStatus(presenter);

  const postStatusTextArea = screen.getByLabelText("postStatusTextArea");
  const postStatusButton = screen.getByLabelText("postStatusButton");
  const clearStatusButton = screen.getByLabelText("clearStatusButton");

  return { user, postStatusTextArea, postStatusButton, clearStatusButton };
}

async function fillFieldAndCheck(
  user: UserEvent,
  postStatusButton: HTMLElement,
  clearStatusButton: HTMLElement,
  postStatusTextArea: HTMLElement,
) {
  await user.type(postStatusTextArea, "a");
  expect(postStatusButton).toBeEnabled();
  expect(clearStatusButton).toBeEnabled();
}
