import {
  anything,
  capture,
  instance,
  mock,
  spy,
  verify,
  when,
} from "@typestrong/ts-mockito";
import {
  PostStatusPresenter,
  PostStatusView,
} from "../../src/presenter/PostStatusPresenter";
import { AuthToken, User } from "tweeter-shared";
import { StatusService } from "../../src/model.service/StatusService";
import React from "react";

describe("PostStatusPresenter", () => {
  let mockPostStatusPresenterView: PostStatusView;
  let postStatusPresenter: PostStatusPresenter;
  let mockStatusService: StatusService;

  const mockEvent = mock<React.MouseEvent>();
  const mockEventInstance = instance(mockEvent);

  const authToken = new AuthToken("abc123", Date.now());
  const currentUser = new User("test", "user", "@test", "");

  beforeEach(() => {
    mockPostStatusPresenterView = mock<PostStatusView>();
    const mockPostStatusPresenterViewInstance = instance(
      mockPostStatusPresenterView,
    );
    when(
      mockPostStatusPresenterView.displayInfoMessage(anything(), 0),
    ).thenReturn("messageId123");

    const postStatusPresenterSpy = spy(
      new PostStatusPresenter(
        mockPostStatusPresenterViewInstance,
        currentUser,
        authToken,
      ),
    );
    postStatusPresenter = instance(postStatusPresenterSpy);

    mockStatusService = mock<StatusService>();

    when(postStatusPresenterSpy.statusService).thenReturn(
      instance(mockStatusService),
    );
  });

  it("tells the view to display a posting status message", async () => {
    await postStatusPresenter.submitPost(mockEventInstance, "Test post");
    verify(
      mockPostStatusPresenterView.displayInfoMessage("Posting status...", 0),
    ).once();
  });

  it("calls postStatus on the post status service with the correct status string and auth token", async () => {
    await postStatusPresenter.submitPost(mockEventInstance, "Test post");
    const [capturedAuthToken, capturedStatus] = capture(
      mockStatusService.postStatus,
    ).last();
    expect(capturedAuthToken).toEqual(authToken);
    expect(capturedStatus.post).toEqual("Test post");
  });

  it("tells the view to clear the info message that was displayed previously, clear the post, and display a status posted message when successful", async () => {
    await postStatusPresenter.submitPost(mockEventInstance, "Test post");
    verify(mockPostStatusPresenterView.deleteMessage("messageId123")).once();
    verify(mockPostStatusPresenterView.setPost("")).once();
    verify(
      mockPostStatusPresenterView.displayInfoMessage("Status posted!", 2000),
    ).once();
    verify(mockPostStatusPresenterView.displayErrorMessage(anything())).never();
  });

  it("tells the view to clear the info message and display an error message but does not tell it to clear the post or display a status posted message when unsuccessful", async () => {
    let error = new Error("An error occurred");
    when(mockStatusService.postStatus(anything(), anything())).thenThrow(error);

    await postStatusPresenter.submitPost(mockEventInstance, "Test post");
    verify(mockPostStatusPresenterView.deleteMessage("messageId123")).once();
    verify(
      mockPostStatusPresenterView.displayErrorMessage(
        "Failed to post the status because of exception: An error occurred",
      ),
    ).once();
    verify(mockPostStatusPresenterView.setPost("")).never();
    verify(
      mockPostStatusPresenterView.displayInfoMessage("Status posted!", 2000),
    ).never();
  });
});
